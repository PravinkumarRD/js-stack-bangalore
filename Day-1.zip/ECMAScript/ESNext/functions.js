//Sales Net Profit Calculation - COGS, expense, actual sales, gst

function getItGstPercent() {
  return 10;
}
//Default Parameters
function salesNetProfit(
  cogs,
  expense = 15000,
  actualSales,
  gstPercent = getItGstPercent()
) {
  const gstAmount = (actualSales * gstPercent) / 100;
  return actualSales - (cogs + expense + gstAmount);
}

console.log(
  `Sales Profit of Bajaj without GST is INR ${salesNetProfit(
    12000,
    13000,
    150000
  )}/-`
);
console.log(
  `Sales Profit of Bajaj with 18% GST is INR ${salesNetProfit(
    12000,
    undefined,
    150000,
    18
  )}/-`
);

//How do you pass limitless/unbound number of parameters to the function?
//In ES6, REST Parameter - packs the comma separated in an array
//There can be only one rest parameter per function and it must be the last parameter in the list

function getBajajOffices(country, ...cities) {
  console.log(country);
  console.log(cities);
}
getBajajOffices("India", "Bangalore", "Chennai", "Hyderabad", "Pune");
getBajajOffices("UAE", "Dubai", "Abu Dhabi", "Oman");
const UsaCities = ["L.A", "New York", "San"];
//SPREAD Operator - Unpacks the collection [Array/Object] values
getBajajOffices("USA", ...UsaCities);

const PizzaOrder = {
  customerId: 2392,
  orderId: 99090,
  orderDate: new Date(),
  pizzaName: "Italian Pizza",
  status: "Your order has been accepted by pizza Hut!",
};
const PizzaInOven = {
  ...PizzaOrder,
  status: "Your Pizza is getting baked!",
};
console.log(PizzaOrder);
console.log(PizzaInOven);

