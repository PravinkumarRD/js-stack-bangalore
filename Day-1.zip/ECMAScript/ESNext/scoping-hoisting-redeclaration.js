//ES6 - let
{
  var myName = "Pravinkumar R. D.";
}
//console.log(myName);
if (true) {
  let company = "Bajaj";
}
//console.log(company);

for (let i = 0; i < 5; i++) {
  //some logic
}
//console.log(i);
console.log(friend); //Hoisting
let friend = "Manish Kaushik"; //is hoisted in TDZ - Temporal Dead Zone

{let num1 = 100;}
var num1 = "100";
console.log(typeof num1);