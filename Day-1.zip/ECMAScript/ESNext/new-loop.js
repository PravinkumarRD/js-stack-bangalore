//For-Of

const Offices = ["Bangalore", "Chennai", "Delhi", "Hyderabad"];

for (const city of Offices) {
  //if (city === "Delhi") break;
  console.log(city);
}



const result = Offices[Symbol.iterator]();
console.log(result.next());
console.log(result.next());
console.log(result.next());
console.log(result.next());
console.log(result.next());
console.log(Offices.filter(city=>city==="Delhi"));
