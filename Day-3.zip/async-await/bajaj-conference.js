const BajajOffices = ["Bangalore", "Chennai", "Hyderabad", "Mumbai", "Pune"];

async function confirmNominations(cities) {
  return new Promise((resolve, reject) => {
    if (cities.length >= 4) {
      resolve(cities);
    } else {
      reject(
        "Less nominations received from Bajaj Offices! Conference cancelled!"
      );
    }
  });
}
async function travelBooking(cities) {
  return new Promise((resolve, reject) => {
    //cities.shift();
    for (const city of cities) {
      console.log(
        `Travel booking has been initiated for the employees from the city ${city}`
      );
    }
    resolve(cities);
  });
}
async function hotelBooking(cities) {
  return new Promise((resolve, reject) => {
    for (const city of cities) {
      console.log(
        `Hotel booking has been initiated for the employees from the city ${city}`
      );
    }
    resolve();
  });
}

async function arrangeConference(cities) {
  try {
    const confirmedCities = await confirmNominations(cities);
    const travelCities = await travelBooking(confirmedCities);
    await hotelBooking(travelCities);
  } catch (error) {
    console.log(`Error - ${error}`);
  } finally {
    console.log("Bajaj Conference workflow is completed!");
  }
}
arrangeConference(BajajOffices);
