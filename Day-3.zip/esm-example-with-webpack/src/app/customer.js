console.log("Customer Module started!");
//export default class Customer {
class Customer {
  constructor() {
    console.log("Customer Constructor Executed!");
  }
  contactName;
  getCustomerName() {
    return `Customer name is ${this.contactName}!`;
  }
}

export default new Customer();

console.log("Customer Module Ended!");
