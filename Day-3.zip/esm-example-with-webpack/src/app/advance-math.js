console.log("Advance Math Module started!");
export function square(num) {
  return num * num;
}
export function squareRoot(num) {
  return Math.sqrt(num);
}
console.log("Advance Math Module Ended!");
