console.log("Basic Math Module started!");
import { square } from "./advance-math";
function addition(num1, num2) {
  return num1 + num2;
}
function subtraction(num1, num2) {
  return num1 - num2;
}
function multiplication(num1, num2) {
  return num1 * num2;
}
function division(num1, num2) {
  return num1 / num2;
}

console.log(`Square of 35 is ${square(35)}!`);

export { addition, multiplication, square };

console.log("Basic Math Module Ended!");
