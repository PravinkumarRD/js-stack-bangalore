console.log("Main Module started!");
import * as BajajMath from "./app/basic-math";
import customer1 from "./app/customer";
import customer2 from "./app/customer";

console.log(`Addition - ${BajajMath.addition(100,200)}`);
console.log(`Multiplication - ${BajajMath.multiplication(100,200)}`);

customer1.contactName="Manish Kaushik";
console.log(customer1.getCustomerName());

console.log(customer2.getCustomerName());

console.log(BajajMath.square(89));

console.log("Main Module Ended!");
