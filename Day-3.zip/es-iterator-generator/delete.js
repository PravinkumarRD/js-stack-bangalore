function* orderNumberGenerator(startNumber,endNumber){
    // yield 1000;
    // yield 1001;
    // yield 1002;
    // yield 1003;
    while (endNumber>=startNumber) {
        yield startNumber++;
    }
}

for (const ordNo of orderNumberGenerator(1,10)) {
    console.log(ordNo);
}