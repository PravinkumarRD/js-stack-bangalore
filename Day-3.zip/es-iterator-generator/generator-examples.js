//Genarators are function

// function* getFiveOrders() {
//     yield 1001;
//     yield 1002;
//     yield 1003;
//     yield 1004;
//     yield 1005;
// }

//const result=getFiveOrders();

// console.log(result.next());
// console.log(result.next());
// console.log(result.next());
// console.log(result.next());
// console.log(result.next());
// console.log(result.next());
// for (const orderNo of getFiveOrders()) {
//     console.log(orderNo);
// }

// function* getQueueNumbers(startNumber,endNumber) {
//     //let num = 1;
//     while (startNumber<=endNumber) {
//         yield startNumber++;
//     }
// }
// for (const queueNo of getQueueNumbers(120,200)) {
//     console.log(queueNo);
// }

async function* getFiveOrders() {
    yield 1001;
    yield 1002;
    yield 1003;
    yield 1004;
    yield 1005;
}

//Async For-Of Loop

(async ()=>{
    for await (const ordNo of getFiveOrders()) {
        console.log(ordNo);
    }
})();