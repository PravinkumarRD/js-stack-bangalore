const OrderNumberIterator = {
    [Symbol.iterator]() {
        let orderNumber = 0;
        return {
            next() {
                let value = orderNumber === 50 ? undefined : orderNumber += 5;
                let done = !value;
                return {
                  value,
                  done,
                };
              },
        };
    },
};

for (const orderNo of OrderNumberIterator) {
    if(orderNo>101) break;
    console.log(orderNo);
}
