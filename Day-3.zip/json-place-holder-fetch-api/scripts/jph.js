//jQuery - DOM Ready Function
$(async () => {
  const tableBody = $("#postsTable");
//   const response = await fetch('https://jsonplaceholder.typicode.com/posts');
//   const posts = await response.json();
    const posts = await( await(fetch('https://jsonplaceholder.typicode.com/posts'))).json();
    for (const post of posts) {
        let row=`
            <tr>
                <td>${post.userId}</td>
                <td>${post.id}</td>
                <td>${post.title}</td>
                <td>${post.body}</td>
            </tr>
        `;
        tableBody.append(row);
    }
});
