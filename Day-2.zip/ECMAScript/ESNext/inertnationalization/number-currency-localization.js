function localizeNumber(locale = "en-IN", value = 0, currencyName = "INR") {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency: currencyName,
    maximumFractionDigits: 2,
    minimumFractionDigits: 2,
  }).format(value);
}

console.log(localizeNumber("en-UK", 1200, "EUR"));
