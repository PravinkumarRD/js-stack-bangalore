const BajajOffices = ["Bangalore", "Chennai", "Hyderabad"];

const conference = new Promise((resolve, reject) => {
  setTimeout(() => {
    if (BajajOffices.length >= 4) {
      resolve(BajajOffices);
    } else {
      reject("Less nomiations from different cities!");
    }
  }, 3000);
});

conference
  .then(
    (cities) => Promise.resolve(cities),
    (reason) => Promise.reject(reason)
  )
  .then((nominatedCities) => {
    for (const city of nominatedCities) {
      console.log(`Travel arrangement is done for city ${city}!`);
    }
    return Promise.resolve(nominatedCities);
  })
  .then(hotelBookingCities=>{
    for (const city of hotelBookingCities) {
        console.log(`Hotel booking is done for city ${city}!`);
      }
      return Promise.resolve(hotelBookingCities);
  })
  .catch((reason) => console.log(`From Catch Block - ${reason}`))
  .finally(() => console.log("Conference workflow is completed!"));
