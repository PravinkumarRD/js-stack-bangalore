const task1 = new Promise((resolve, reject) => {
  setTimeout(() => {
    //reject("Task - 1 is not completed!");
    resolve("Task - 1 is completed!");
  }, 500);
});
const task2 = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve("Task - 2 is completed!");
    //reject("Task - 2 is not completed!");
  }, 5000);
});
const task3 = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve("Task - 3 is completed!");
  }, 3000);
});

// Promise.all([task2,task1, task3]).then(
//   (tasks) => console.log(tasks),
//   (reason) => console.log(reason)
// );
Promise.race([task2, task3, task1]).then(
  (tasks) => console.log(tasks),
  (reason) => console.log(reason)
);
