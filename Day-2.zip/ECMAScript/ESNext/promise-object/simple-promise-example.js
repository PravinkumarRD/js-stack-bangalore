function task1() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve("Task - 1 is completed!");
      //reject("Found bug! Task-1 is not completed!");
    }, 5000);
  });
}

console.log('I am first line!');

const projectTask1 = task1();
console.log('I am Second line!');
projectTask1.then(
  (value) => console.log(`Fullfillment of Promise ${value}`),
  (reason) => console.log(`Rejection of Promise ${reason}`)
);
console.log('I am Third line!');
