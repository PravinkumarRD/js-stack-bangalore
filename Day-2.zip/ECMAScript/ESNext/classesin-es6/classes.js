//It is a syntactic sugar

class Person {
  constructor(fname, lname, city) {
    console.log("Person Class Constructor Executed!");
    this.firstName = fname;
    this.lastName = lname;
    this.city = city;
    console.log(arguments);
  }
  //public
  //firstName;
  #_firstName;
  get firstName() {
    return this.#_firstName;
  }
  set firstName(value) {
    //if (!value) throw new Error("First name is required field!");
    this.#_firstName = value;
  }
  lastName;
  city;
  getPersonInfo() {
    //console.log(this);
    return `Person named ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
  }

  #_socialId;
}

//IS-A - Customer-Is-A-Person
class Customer extends Person {
  static counter = 0;
  constructor(fname, lname, city, cid) {
    super(fname, lname, city);
    this.customerId = cid;
    ++Customer.counter;
    console.log(`Total number of instances are - ${Customer.counter}`);
  }
  customerId;
  static totalInstances(){
    return Customer.counter;
  }
}

//const person = new Person("Manish", "Kaushik", "Raipur");
const person = new Customer();
person.firstName = "Manish";
person.lastName = "Sharma";
person.city = "Delhi";
console.log(person.getPersonInfo());
console.log(typeof Person);
const c1 = new Customer();
const c2 = new Customer();
const c3 = new Customer();
class A {
  X;
}
class B extends A {
  Y;
}
class C extends B {
  Z;
}
const c = new C();
console.log(Customer.totalInstances());