const PI = 3.14;

const MyWorkingOffices = ["Bangalore","Delhi","Chennai","Mumbai"];
MyWorkingOffices.push("Pune");
console.log(MyWorkingOffices);

MyWorkingOffices=[];