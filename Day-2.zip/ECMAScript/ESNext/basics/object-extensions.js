const Order = {
    orderId: 3499,
    orderDate: new Date(),
    quantity: 89,
    unitPrice: 12.9,
};
Object.defineProperty(Order, "requiredDate", {
    enumerable: false,
    value: new Date()
});

const Customer = {
    customerId: 3489,
    contactName: "Manish sharma",
    city: "Pune",
};

//Copy all properties of Order object into Customer Object - Not Good in terms of performance
// Object.setPrototypeOf(Customer, Order);
// console.log(Customer.requiredDate);

//const CustomerOrder = { ...Customer, ...Order };
 const CustomerOrder = {};
 Object.assign(CustomerOrder, Customer, Order);
console.log(CustomerOrder);
