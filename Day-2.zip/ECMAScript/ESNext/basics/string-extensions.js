let message = "Welcome To Bajaj Banglore!";
console.log(message.toLocaleLowerCase().startsWith("w"));
console.log(message.toLocaleLowerCase().endsWith("ore!"));
console.log(message.toLocaleLowerCase().includes("bajaj"));