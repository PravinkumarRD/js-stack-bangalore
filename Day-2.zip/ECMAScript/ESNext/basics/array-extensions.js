const numbersArray1 = new Array(100);

console.log(numbersArray1.length);
const numbersArray2 = Array.of(100);
console.log(numbersArray2.length);

const TrainingLocations = [
  "Bangalore",
  "Chennai",
  "Dubai",
  "Kuwait",
  "Singapore",
  "Mumbai",
];

console.log(TrainingLocations.find((city) => city === "Hyderabad"));

const PriceList = [340, 560, 780, 230];

// const DiscountedAmounts = Array.from(
//   PriceList,
//   (amt) => amt - (amt * 10) / 100
// );
const DiscountedAmounts = Array.from(
    PriceList,
    function(amt){
        return amt - (amt * this.discountPercentage) / 100
    },{
      discountPercentage:18
    }
  );
console.log(DiscountedAmounts);
