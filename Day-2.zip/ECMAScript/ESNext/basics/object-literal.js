let employeeId = 2389,
  empName = "Alisha C.",
  city = "Mumbai",
  company = "Bajaj Ltd.";

const Employee={
    employeeId,
    employeeName:empName,
    city,
    company
};
console.log(Employee);