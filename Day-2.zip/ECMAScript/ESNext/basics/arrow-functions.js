const Customer = {
  customerId: 2892,
  contactName: "Pravinkumar R. D.",
  city: "Pune",
  getCustomerInfo: function () {
    console.log(this);
    setTimeout(() => {
      console.log(this);
      console.log(`Customer ${this.contactName} 
    lives in city ${this.city} has customer Id ${this.customerId}!`);
    }, 2000);
  },
};
//Customer.getCustomerInfo();

//Short syntaxes

const log = () => console.log("This is my logger!");
log();

const sqaure = num => num * num;
console.log(sqaure(12));

const salesNetProfit = (cogs, expense, actualSales, gstPercent) => {
  //logic
  const gstAmount = (actualSales * gstPercent) / 100;
  return actualSales - (cogs + expense + gstAmount);
};
