const Customer = {
  customerId: 2892,
  contactName: "Pravinkumar R. D.",
  city: "Pune",
};

console.log(`Customer ${Customer.contactName} 
    lives in city ${Customer.city} has customer Id ${Customer.customerId}!`);

let row=`
    <tr>
        <td>${Customer.customerId}</td>
        <td>${Customer.contactName}</td>
        <td>${Customer.city}</td>
    </tr>
`;

function getCustomerInfo(){
    return `Customer ${Customer.contactName} 
    lives in city ${Customer.city} has customer Id ${Customer.customerId}!`;
}
console.log(getCustomerInfo());