const Mobiles = ["Apple 6", "Samsung Galaxy", "Nokia 6", "Apple 12", "Moto G"];
//let [m1, ,m3, m4, m5]=Mobiles;

let [m1, ...companies] = Mobiles;
console.log(companies);

let message = "Welcome";
let [s1, s2, s3] = message;
console.log(s2);

const Customer = {
  customerId: 2389,
  contactName: "Manish Sharma",
  city: "Pune",
};

let custId, customerName, livingCity;
({
  customerId:custId,
  contactName:customerName,
  city:livingCity,
} = Customer);
console.log(customerName);
customerName="Alisha C.";
console.log(Customer);