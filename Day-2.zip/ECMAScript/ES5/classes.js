//Function-As-A-class
function Person(fname, lname, city) {
  //public
  this.firstName = fname;
  this.lastName = lname;
  this.city = city;

  this.getPersonInfo = function () {
    return (
      "Person name is " +
      this.firstName +
      " " +
      this.lastName +
      " lives in city " +
      this.city
    );
  };

  //Private
  var _socialId;
}

var person = new Person("Alisha", "C.", "Mumbai");
console.log(person.getPersonInfo());