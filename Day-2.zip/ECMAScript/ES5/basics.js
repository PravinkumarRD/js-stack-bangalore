//No Block Scoping in ES5 [Function, Clouser, IIFE, Namespace]
//JavaScript will hoist variables and functions declaration
//Re-declaration of the varibles are allowed in a scope
/*
console.log(hrMessage());
console.log(anotherHrMessage);
{
  var myName = "Pravinkumar R. D.";
}
console.log(myName);
if (true) {
  var company = "Bajaj";
}
console.log(company);

for (var i = 0; i < 5; i++) {
  //some logic
}
console.log(i);

console.log(friend); //Hoisting
var friend = "Manish Kaushik";

function hrMessage() {
  return "WelCome to Bajaj!";
}
//Function-As-An-Expression
var anotherHrMessage = function () {
  return "WelCome to Bajaj!Bangalore!";
};

var num1 = 100;
var num1 = "100";
console.log(typeof num1);

//Clouser -

function trainingInfo(trainingName) {
  var trainerName = "Pravinkumar R. D.";
  return function () {
    return (
      "Welcome To Training - " +
      trainingName +
      "! Trainer name is " +
      trainerName
    );
  };
  //return "Welcome To Training - " + trainingName + "! Trainer name is " + trainerName;
}

var info = trainingInfo("JavaScript Full Stack");
//20 lines of code
console.log(info());

// var Bajaj = {
//   location: "Bangalore",
// };

//IIFE - Immediately Invoked Function Expression

var BajajCalci = (function () {
  console.log("IIFE");
  var addition = function (num1, num2) {
    return num1 + num2;
  };
  var subtraction = function (num1, num2) {
    return num1 + num2;
  };
  var multiplication = function (num1, num2) {
    return num1 + num2;
  };
  return {
    addition: addition,
    subtraction: subtraction,
    multiplication: multiplication,
  };
  //return "This is an IIFE!";
})();
console.log(BajajCalci.addition(100, 200));

//Namespace

var Bajaj = Bajaj || {};
Bajaj.department = "IT Department";
Bajaj.getDepartmentInfo = function () {
  return this.department;
};
Bajaj["location"] = "Pune";
console.log(Bajaj.location);
console.log(Bajaj.department);
console.log(Bajaj.getDepartmentInfo());

Object.defineProperty(this, "PI", {
  writable: false,
  value: 3.14,
});

var Customer = {
  customerId: 2892,
  contactName: "Pravinkumar R. D.",
  city: "Pune",
};
//Customer Pravinkumar R. D. lives in city Pune has customer Id 2892!

console.log("Customer "+Customer.contactName+" lives in city " + Customer.city + " has Customer Id " + Customer.customerId);
console.log("Customer %s lives in city %s has customer Id %d",Customer.contactName,Customer.city,Customer.customerId);

function getCustomerInfo(){
    return "Customer "+Customer.contactName+" lives in city " + Customer.city + " has Customer Id " + Customer.customerId;
    //return "Customer %s lives in city %s has customer Id %d",Customer.contactName,Customer.city,Customer.customerId;
}
console.log(getCustomerInfo());

var x = 100;
var y = "100";
//console.log(x === y);

var offices = ["Bangalore", "Chennai", "Delhi", "Hyderabad"];

for (var i = 0; i < offices.length; i++) {
  if (offices[i] === "Delhi") break;
  console.log(offices[i]);
}
console.log("");
offices.forEach(function (city) {
    if(city==="Delhi") return;
  console.log(city);
});
//Functions
function addition(num1) {
    return num1 + 1000;
  }
  function addition(num1, num2) {
    return num1 + num2;
  }
  function addition(num1, num2, num3) {
    if (!num1) num1 = 0;
    if (!num2) num2 = 0;
    if (!num3) num3 = 0;
    return num1 + num2 + num3;
  }
  console.log(addition());
  console.log(addition(1000));
  console.log(addition(1000, 2000));
  console.log(addition(1000, 2000, 3000));
  
  function multiplication() {
    if (arguments.length === 1) return arguments[0] * 100;
    if (arguments.length === 2) return arguments[0] * arguments[1];
    if (arguments.length === 3) return arguments[0] * arguments[1] * arguments[2];
  }
  
  console.log(multiplication(100, 30));
  console.log(multiplication(100, 30, 30));
  console.log(multiplication(100));


window.contactName="Manish K.";

var Customer = {
  customerId: 2892,
  contactName: "Pravinkumar R. D.",
  city: "Pune",
//   getCustomerInfo:function(){
//     console.log(this);
//     setTimeout(function(){
//         console.log(this);
//         console.log("Customer "+this.contactName+" lives in city " + this.city + " has Customer Id " + this.customerId);
//     },2000);
//   }
    // getCustomerInfo:function(){
    //     //this aliasing
    //     var _self=this;
    // console.log(this);
    // setTimeout(function(){
    //     console.log(_self);
    //     console.log("Customer "+_self.contactName+" lives in city " + _self.city + " has Customer Id " + _self.customerId);
    // },2000);
  //}
    getCustomerInfo:function(){
    console.log(this);
    setTimeout(function(){
        console.log(this);
        console.log("Customer "+this.contactName+" lives in city " + this.city + " has Customer Id " + this.customerId);
    }.bind(this),2000);
  }
};
Customer.getCustomerInfo();
  */

function task1(){
  console.log('Task-1 Started!');
  setTimeout(() => {
    return 'Task-1 is completed!';
  }, 5000);
  console.log('Task-1 Delivered!');
}

var output = task1();
console.log(output);