//Functions written with function keyword has implicit binding with this keyword which intern will change the owner/context based on requirements
//Arrow functions does not have binding with this context

const Employee = {
    employeeId: 2399,
    employeeName: 'Alisha C.',
    city: 'Mumbai',
    // getEmployeeInfo: function () {
    //     //this keyword aliasing
    //     let _self = this;
    //     setTimeout(function () {
    //         console.log(`Employee ${_self.employeeName} lives in city ${_self.city}`);
    //     }, 3000);
    // }
    // getEmployeeInfo: function () {
    //     setTimeout(function () {
    //         console.log(`Employee ${this.employeeName} lives in city ${this.city}`);
    //     }.bind(this), 3000);
    // }
    getEmployeeInfo: function () {
        setTimeout(() => {
            console.log(`Employee ${this.employeeName} lives in city ${this.city}`);
        }, 3000);
    }
}
Employee.getEmployeeInfo();

// function log(){
//     console.log('This is my log!');
// }
const log = () => console.log('This is my log!');
log();
// function square(num) {
//     return num * num;
// }
const square = (num: number) => num * num;
console.log(square(10));