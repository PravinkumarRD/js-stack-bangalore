console.log("Welcome To First Typescript Example!!!");
console.log("Bajaj Finance Ltd!");