//never type is used when your method will never return you anything
//For example - exception method
function logException(): never {
    throw new Error("This is an exception!");
}

let bajajHrMessage: string = "Welcome To Bajaj Training!";
let bajajBangaloreOfficeCode: number = 2389;
//unknown
let message: unknown;
message = bajajHrMessage;
message = bajajBangaloreOfficeCode;

// let myMessage: string = message;
// let myNumber: number = message;