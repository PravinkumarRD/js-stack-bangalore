// function salesNetProfit(cogs: number, expense: number, actualSales: number): number {
//     return actualSales - (cogs + expense);
// }
//All the parameters of Typescript function are compulsory
//All optional parameter must be declared after required parameters/may be at the end
function salesNetProfit(cogs: number, expense: number = 15000, actualSales: number, gstPercent?: number): number {
    if (!gstPercent) gstPercent = 0;
    let gstAmount: number = actualSales * gstPercent / 100;
    return actualSales - (cogs + expense + gstAmount);
}
salesNetProfit(12000, 13000, 150000);
salesNetProfit(12000, undefined, 150000, 18);

//How to make function parameter(s) optional in Typescript? Use ? 