//Implement Search products functionality by two ways - 
//1) Search Products by CompanyName and 2) Search Products By Stock
const OriginalProducts = [
    {
        productId: 3829,
        productName: 'Apple 13 Pro',
        unitPrice: 97000,
        company: 'Apple',
        availableQuantity: 23
    },
    {
        productId: 3830,
        productName: 'Apple 14 Pro',
        unitPrice: 123000,
        company: 'Apple',
        availableQuantity: 45
    },
    {
        productId: 3831,
        productName: 'Samsung Galazy',
        unitPrice: 37000,
        company: 'Samsung',
        availableQuantity: 67
    },
    {
        productId: 3832,
        productName: 'Samsung Note',
        unitPrice: 77000,
        company: 'Samsung',
        availableQuantity: 50
    },
    {
        productId: 3833,
        productName: 'Nokia 7',
        unitPrice: 27000,
        company: 'Nokia',
        availableQuantity: 56
    }
];

function searchProducts(companyName: string): string[];
function searchProducts(availableStock: number): string[];
function searchProducts(value: number | string): string[] {
    const productsCopy = [...OriginalProducts];
    const foundProducts: string[] = [];
    if (typeof (value) === 'string') {
        for (const product of productsCopy) {
            if (product.company === value) foundProducts.push(product.productName);
        }
    } else {
        for (const product of productsCopy) {
            if (product.availableQuantity > value) foundProducts.push(product.productName);
        }
    }
    return foundProducts;
}

console.log(searchProducts('Samsung'));
console.log(searchProducts(34));