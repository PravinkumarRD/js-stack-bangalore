"use strict";
{
    let no1 = 100;
}
//console.log(no1);
//console.log(no2);
let no2 = 1000;
//let no2=10000;
//# sourceMappingURL=re-declaration-scope-hoisting.js.map