"use strict";
//Type Inference - Typescript compiler will infer the type upon initialzation of the variabe from the existing type system and will retain the same type throughout the program
let isBlackListed = true;
//let isBlackListed = true;
isBlackListed = 1;
isBlackListed = true;
let myAge = 90;
//myAge='Ninty';
//Typescript compiler will infer a new type called any which can accept any type of value. Discouraged to be used
let myWorkingCompanyName;
myWorkingCompanyName = "ABCD";
myWorkingCompanyName = 23892;
myWorkingCompanyName = true;
//Type Annotations - simple/single and Union Type
let myCompany;
myCompany = "Bajaj Lts.";
myCompany = 411051;
myCompany = true;
function addition(no1, no2) {
    console.log(no1 + no2);
}
//# sourceMappingURL=type-inference-type-annotations.js.map