"use strict";
var Menu;
(function (Menu) {
    Menu[Menu["AMERICAN"] = 1] = "AMERICAN";
    Menu[Menu["INDIAN"] = 5] = "INDIAN";
    Menu[Menu["ITALIAN"] = 6] = "ITALIAN";
    Menu[Menu["JAPANESE"] = 7] = "JAPANESE";
})(Menu || (Menu = {}));
const CustomerOrder = Menu.AMERICAN;
console.log(+CustomerOrder);
switch (+CustomerOrder) {
    case 1:
        console.log('Customer has ordered American food!');
        break;
    case 5:
        console.log('Customer has ordered Indian food!');
        break;
    case 6:
        console.log('Customer has ordered Italian food!');
        break;
    case 7:
        console.log('Customer has ordered Japanese food!');
        break;
    default:
        console.log('We do not serve this food!');
        break;
}
//# sourceMappingURL=enum-examples.js.map