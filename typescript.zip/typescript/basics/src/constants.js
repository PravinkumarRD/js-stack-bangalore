"use strict";
const PI = 3.14;
const BajajEmployee = {
    employeeId: 2390,
    employeeName: 'Alicia Johns',
    city: 'Berlin'
};
BajajEmployee.city = "London";
// BajajEmployee={
// };
//# sourceMappingURL=constants.js.map