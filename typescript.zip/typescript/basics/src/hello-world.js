"use strict";
console.log("Welcome To First Typescript Example!!!");
console.log("Bajaj Finance Ltd!");
//# sourceMappingURL=hello-world.js.map