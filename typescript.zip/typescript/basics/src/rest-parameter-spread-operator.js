"use strict";
//REST parameter will pack the comma separated values in an array. Passing unlimited parameters to the function
function workingCities(...cities) {
    console.log(cities);
}
workingCities("Bangalore", "Chennai", "Delhi");
workingCities("Bangalore", "Chennai", "Delhi", "Hyderabad");
workingCities("Bangalore", "Hyderabad");
const BajajNewOffices = ["Bangalore", "Chennai", "Delhi", "Hyderabad", "Mumbai", "Pune"];
//SPREAD Operator - Unpacks the collection values
workingCities(...BajajNewOffices);
const PizzaOrder = {
    pizzaId: 2389,
    orderId: 2389,
    customerId: 237655,
    pizzaName: 'Veg Pizza',
    price: 1200,
    orderDate: new Date(),
    status: 'Pizza Hut has acceepted your order!'
};
const PizzaInOven = {
    ...PizzaOrder,
    status: 'Your pizza is getting baked'
};
console.log(PizzaOrder);
console.log(PizzaInOven);
//# sourceMappingURL=rest-parameter-spread-operator.js.map