"use strict";
//never type is used when your method will never return you anything
//For example - exception method
function logException() {
    throw new Error("This is an exception!");
}
let bajajHrMessage = "Welcome To Bajaj Training!";
let bajajBangaloreOfficeCode = 2389;
//unknown
let message;
message = bajajHrMessage;
message = bajajBangaloreOfficeCode;
// let myMessage: string = message;
// let myNumber: number = message;
//# sourceMappingURL=unknown-never.js.map