"use strict";
var Payment;
(function (Payment) {
    let COD;
    (function (COD) {
        function processPayment(customerId, totalAmount) {
            return `Customer Id ${customerId} has made payment of INR ${totalAmount}/- by Cash!`;
        }
        COD.processPayment = processPayment;
    })(COD = Payment.COD || (Payment.COD = {}));
    let Wallet;
    (function (Wallet) {
        function processPayment(customerId, totalAmount, walletName) {
            return `Customer Id ${customerId} has made payment of INR ${totalAmount}/- using Wallet ${walletName}!`;
        }
        Wallet.processPayment = processPayment;
    })(Wallet = Payment.Wallet || (Payment.Wallet = {}));
    let CreditCard;
    (function (CreditCard) {
        function processPayment(customerId, totalAmount, bankName, cardType) {
            return `Customer Id ${customerId} has made payment of INR ${totalAmount}/- from the Bank ${bankName} and card type is ${cardType}!`;
        }
        CreditCard.processPayment = processPayment;
    })(CreditCard = Payment.CreditCard || (Payment.CreditCard = {}));
})(Payment || (Payment = {}));
console.log(Payment.COD.processPayment(2379, 1200));
console.log(Payment.CreditCard.processPayment(2991, 12000, "HDFC", "Visa"));
//# sourceMappingURL=namespaces.js.map