"use strict";
const MyWorkingOffices1 = ["Bangalore", "Chennai"];
const MyWorkingOffices2 = ["Bangalore", "Chennai", 1000];
//# sourceMappingURL=strongly-typed-array.js.map