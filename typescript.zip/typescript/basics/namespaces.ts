namespace Payment {
    export namespace COD {
        export function processPayment(customerId: number, totalAmount: number): string {
            return `Customer Id ${customerId} has made payment of INR ${totalAmount}/- by Cash!`;
        }
    }
    export namespace Wallet {
        export function processPayment(customerId: number, totalAmount: number, walletName: string): string {
            return `Customer Id ${customerId} has made payment of INR ${totalAmount}/- using Wallet ${walletName}!`;
        }
    }
    export namespace CreditCard {
        export function processPayment(customerId: number, totalAmount: number, bankName: string, cardType: string): string {
            return `Customer Id ${customerId} has made payment of INR ${totalAmount}/- from the Bank ${bankName} and card type is ${cardType}!`;
        }
    }
}

console.log(Payment.COD.processPayment(2379, 1200));
console.log(Payment.CreditCard.processPayment(2991, 12000, "HDFC", "Visa"));