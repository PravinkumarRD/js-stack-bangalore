const MyWorkingOffices1: string[] = ["Bangalore", "Chennai"];

const MyWorkingOffices2: (string|number)[] = ["Bangalore", "Chennai",1000];