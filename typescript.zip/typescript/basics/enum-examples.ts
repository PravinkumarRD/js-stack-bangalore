enum Menu {
    AMERICAN = 1,
    INDIAN = 5,
    ITALIAN,
    JAPANESE
}

const CustomerOrder: Menu = Menu.AMERICAN;
console.log(+CustomerOrder);

switch (+CustomerOrder) {
    case 1:
        console.log('Customer has ordered American food!')
        break;
    case 5:
        console.log('Customer has ordered Indian food!')
        break;

    case 6:
        console.log('Customer has ordered Italian food!')
        break;
    case 7:
        console.log('Customer has ordered Japanese food!')
        break;
    default:
        console.log('We do not serve this food!')
        break;
}