"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.division = exports.multiplication = exports.subtraction = exports.addition = void 0;
console.log('Basic Math Module Started!');
const advance_math_1 = require("./advance-math");
function addition(num1, num2) {
    return num1 + num2;
}
exports.addition = addition;
function subtraction(num1, num2) {
    return num1 - num2;
}
exports.subtraction = subtraction;
function multiplication(num1, num2) {
    return num1 * num2;
}
exports.multiplication = multiplication;
function division(num1, num2) {
    return num1 / num2;
}
exports.division = division;
console.log(`Sqaure of 56 is ${(0, advance_math_1.square)(56)}`);
console.log('Basic Math Module Loaded!');
//# sourceMappingURL=basic.math.js.map