"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.square = void 0;
console.log('Advance Math Module Started!');
function square(num) {
    return num * num;
}
exports.square = square;
function squareRoot(num) {
    return Math.sqrt(num);
}
console.log('Advance Math Module Loaded!');
//# sourceMappingURL=advance-math.js.map