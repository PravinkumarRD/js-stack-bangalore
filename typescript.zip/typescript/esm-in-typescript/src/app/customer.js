"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log('Customer Module Started!');
//export default class Customer {
class Customer {
    firstName;
    lastName;
    city;
    getCustomerDetails() {
        return `Customer ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}
//Singleton Object
exports.default = new Customer();
console.log('Customer Module Loaded!');
//# sourceMappingURL=customer.js.map