"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log('Main Module Started!');
//import { addition, multiplication, subtraction, division } from "./app/basic.math";
const BajajMath = require("./app/basic.math");
const customer_1 = require("./app/customer");
const customer_2 = require("./app/customer");
console.log(`Addition ${BajajMath.addition(100, 200)}`);
console.log(`Subtraction ${BajajMath.subtraction(1000, 200)}`);
console.log(`Multiplication ${BajajMath.multiplication(100, 200)}`);
console.log(`Division ${BajajMath.addition(1000, 200)}`);
customer_1.default.firstName = "Alisha";
customer_1.default.lastName = "C.";
customer_1.default.city = "Mumbai";
console.log(customer_2.default.getCustomerDetails());
console.log('Main Module Loaded!');
//# sourceMappingURL=main.js.map