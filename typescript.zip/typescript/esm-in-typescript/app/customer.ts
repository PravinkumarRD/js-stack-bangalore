console.log('Customer Module Started!');
//export default class Customer {
class Customer {
    firstName: string;
    lastName: string;
    city: string;
    getCustomerDetails(): string {
        return `Customer ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}

//Singleton Object
export default new Customer();
console.log('Customer Module Loaded!');