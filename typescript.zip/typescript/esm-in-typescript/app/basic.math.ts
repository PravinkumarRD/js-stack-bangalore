console.log('Basic Math Module Started!');
import { square } from './advance-math';
function addition(num1: number, num2: number): number {
    return num1 + num2;
}
function subtraction(num1: number, num2: number): number {
    return num1 - num2;
}
function multiplication(num1: number, num2: number): number {
    return num1 * num2;
}
function division(num1: number, num2: number): number {
    return num1 / num2;
}

console.log(`Sqaure of 56 is ${square(56)}`);

//Named Exports which you can have as many as you want in a given module
export { addition, subtraction, multiplication, division }
console.log('Basic Math Module Loaded!');