console.log('Advance Math Module Started!');
export function square(num: number): number {
    return num * num;
}
function squareRoot(num: number): number {
    return Math.sqrt(num);
}
console.log('Advance Math Module Loaded!');