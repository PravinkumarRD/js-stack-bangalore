console.log('Main Module Started!');
//import { addition, multiplication, subtraction, division } from "./app/basic.math";
import * as BajajMath from './app/basic.math';
import bajajCustomerObj1 from './app/customer';
import bajajCustomerObj2 from './app/customer';

console.log(`Addition ${BajajMath.addition(100, 200)}`);
console.log(`Subtraction ${BajajMath.subtraction(1000, 200)}`);
console.log(`Multiplication ${BajajMath.multiplication(100, 200)}`);
console.log(`Division ${BajajMath.addition(1000, 200)}`);

bajajCustomerObj1.firstName = "Alisha";
bajajCustomerObj1.lastName = "C.";
bajajCustomerObj1.city="Mumbai";
console.log(bajajCustomerObj2.getCustomerDetails());


console.log('Main Module Loaded!');