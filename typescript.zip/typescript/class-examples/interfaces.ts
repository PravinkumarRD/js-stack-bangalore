interface Physics {
    physicsCalci(): string;
}
interface Chemistry {
    chemistryCalci(): string;
}
interface Biology {
    biologyCalci(): string;
}
//This is multiple inheritance
interface ScienceDepartment extends Physics, Chemistry, Biology {

}
interface ScienceDepartment {
    departmentCalci(): string;
}

class Science implements ScienceDepartment {
    departmentCalci(): string {
        throw new Error("Method not implemented.");
    }
    physicsCalci(): string {
        throw new Error("Method not implemented.");
    }
    chemistryCalci(): string {
        throw new Error("Method not implemented.");
    }
    biologyCalci(): string {
        throw new Error("Method not implemented.");
    }
}

const p1: Physics = new Science();
