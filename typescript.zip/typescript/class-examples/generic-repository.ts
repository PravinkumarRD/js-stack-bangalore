//Templates can be - Methods, Interface and Classes
//T= Primitive Types, Complex Types and Custom Types
interface CommonCurd<T> {
    getAll(): T[];
    getDetails(id: number): T;
    insert(item: T): void;
    update(item: T): void;
    delete(id: number): void;
}

class CommonCrudOperations<T> implements CommonCurd<T>{
    private _localCollectionDb: Array<T> = new Array<T>();
    getAll(): T[] {
        return this._localCollectionDb;
    }
    getDetails(id: number): T {
        return this._localCollectionDb[0];
    }
    insert(item: T): void {
        this._localCollectionDb.push(item);
    }
    update(item: T): void {
        throw new Error("Method not implemented.");
    }
    delete(id: number): void {
        throw new Error("Method not implemented.");
    }
}

class BajajCustomer {
    constructor(public customerId: number, public contactName: string, public city: string) {

    }
}
class BajajProduct {
    constructor(public productId: number, public productName: string, public availableQty: number, public unitPrice: number) {

    }
}

const customer1: BajajCustomer = new BajajCustomer(1200, "Pravinkumar R. D.", "Pune");
const customer2: BajajCustomer = new BajajCustomer(1201, "Priti P. D.", "Delhi");

const product1: BajajProduct = new BajajProduct(786, "Lux Soap", 1200, 56.00);
const product2: BajajProduct = new BajajProduct(787, "Tata Green Tea", 1900, 170.00);

const customerCurd: CommonCurd<BajajCustomer> = new CommonCrudOperations<BajajCustomer>();
customerCurd.insert(customer1);
customerCurd.insert(customer2);
console.log(customerCurd.getAll());
console.log(customerCurd.getDetails(customer1.customerId));

const productCurd: CommonCurd<BajajProduct> = new CommonCrudOperations<BajajProduct>();
productCurd.insert(product1);
productCurd.insert(product2);
console.log(productCurd.getAll());
console.log(productCurd.getDetails(product1.productId));