"use strict";
class CommonCrudOperations {
    _localCollectionDb = new Array();
    getAll() {
        return this._localCollectionDb;
    }
    getDetails(id) {
        return this._localCollectionDb[0];
    }
    insert(item) {
        this._localCollectionDb.push(item);
    }
    update(item) {
        throw new Error("Method not implemented.");
    }
    delete(id) {
        throw new Error("Method not implemented.");
    }
}
class BajajCustomer {
    customerId;
    contactName;
    city;
    constructor(customerId, contactName, city) {
        this.customerId = customerId;
        this.contactName = contactName;
        this.city = city;
    }
}
class BajajProduct {
    productId;
    productName;
    availableQty;
    unitPrice;
    constructor(productId, productName, availableQty, unitPrice) {
        this.productId = productId;
        this.productName = productName;
        this.availableQty = availableQty;
        this.unitPrice = unitPrice;
    }
}
const customer1 = new BajajCustomer(1200, "Pravinkumar R. D.", "Pune");
const customer2 = new BajajCustomer(1201, "Priti P. D.", "Delhi");
const product1 = new BajajProduct(786, "Lux Soap", 1200, 56.00);
const product2 = new BajajProduct(787, "Tata Green Tea", 1900, 170.00);
const customerCurd = new CommonCrudOperations();
customerCurd.insert(customer1);
customerCurd.insert(customer2);
console.log(customerCurd.getAll());
console.log(customerCurd.getDetails(customer1.customerId));
const productCurd = new CommonCrudOperations();
productCurd.insert(product1);
productCurd.insert(product2);
console.log(productCurd.getAll());
console.log(productCurd.getDetails(product1.productId));
//# sourceMappingURL=generic-repository.js.map