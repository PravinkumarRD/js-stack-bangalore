"use strict";
class Science {
    departmentCalci() {
        throw new Error("Method not implemented.");
    }
    physicsCalci() {
        throw new Error("Method not implemented.");
    }
    chemistryCalci() {
        throw new Error("Method not implemented.");
    }
    biologyCalci() {
        throw new Error("Method not implemented.");
    }
}
const p1 = new Science();
//# sourceMappingURL=interfaces.js.map