// class Person {
//     firstName: string;
//     lastName: string;
//     city: string;
//     getPersonInfo(): string {
//         return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
//     }
// }
// class Person {
//     constructor(fname: string, lname: string, city: string) {
//         console.log('Person Constructor called!');
//         this.firstName = fname;
//         this.lastName = lname;
//         this.city = city;
//     }
//     firstName: string;
//     lastName: string;
//     city: string;
//     getPersonInfo(): string {
//         return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
//     }
// }

//Constructor Properties
//In Angular framework, we use this syntax for Dependency Injection
// class Person {
//     constructor(public firstName: string, public lastName: string, public city: string) {
//         console.log('Person Constructor called!');
//     }

//     getPersonInfo(): string {
//         return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
//     }
// }

//Any time you want to validate the data or you want to make your properties readonly or writeonly - you will create properties with get and set syntax [Getter and Setter Properties]
/*class Person {
    constructor() {
        console.log('Person Constructor called!');
    }
    private _firstName: string | undefined;
    public get firstName() {
        return this._firstName;
    }
    public set firstName(v: string | undefined) {
        if (v === null || v === undefined) throw new Error("First name cannot be null or undefined!");
        this._firstName = v;
    }

    private _lastName: string;
    public get lastName(): string {
        return this._lastName;
    }
    public set lastName(v: string) {
        this._lastName = v;
    }

    private _city: string;
    public get city(): string {
        return this._city;
    }
    public set city(v: string) {
        this._city = v;
    }

    getPersonInfo(): string {
        return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}*/
// const person: Person = new Person("Alisha", "C.", "Mumbai");

//You cannot create an instance of an Abstract class. But abstract class can have constructuor. There should be [not necessarily] atleast one abstract  member in an abstract class
abstract class Person {
    constructor(public firstName?: string, public lastName?: string, public city?: string) {
        console.log('Person Constructor called!');
    }
    address: string;
    getPersonInfo(): string {
        return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
    abstract changeAddress(oldAddress: string, newAddress: string): boolean;
}

//Customer IS-A Person Relationship
class Customer extends Person {
    constructor() {
        super();
        console.log('Customer Constructor is called!');
    }
    customerId: number;
    changeAddress(oldAddress: string, newAddress: string): boolean {
        console.log(`${this.firstName} ${this.lastName} has changed his/her address from ${oldAddress} to ${newAddress}!`);
        return true;
    }

}
//const person: Person = new Person();
const person: Customer = new Customer();
person.address = "MoonCity";
person.firstName = 'Manish';
person.lastName = "Kaushik";
person.city = "Bangalore";
console.log(person.getPersonInfo());
console.log(person.changeAddress(person.address, "Suncity"));
console.log(typeof (Person));

//Only Multilevel inheritance is supported.
//Multiple inheritance is not supported in Typescript
class GrandParent {
    protected a: number;
}

class Parent extends GrandParent {
    constructor() {
        super();
    }
    protected b: number;
}
class Child extends Parent {
    constructor() {
        super();
    }
    c: number;
}

const c1: Child = new Child();

//Constructor Overloading
class Employee {
    employeeId: number;
    employeeName: string;
    city: string;
    constructor();
    constructor(eid: number);
    constructor(ename: string, city: string);
    constructor() {
        if (arguments.length === 0) {
            console.log('Default Constructor is called!');
        } else if (arguments.length === 1) {
            console.log('One Parameterized Constructor is called!');
        } else {
            console.log('Two Parameterized Constructor is called!');
        }
    }
}
new Employee();
new Employee(3892);
new Employee("Pravin", "Pune");

class Counter {
    static count: number = 1;
    constructor() {
        console.log(`Counter class instance no. is ${Counter.count++}`);
    }
    static getTotalInstancesCount(){
        return Counter.count;
    }
}

new Counter();
new Counter();
new Counter();

console.log(`Total Counter instances are ${Counter.getTotalInstancesCount()}`);
