function gst(gstPercentage: number) {
    return function (target: Object, key: string, descriptor: PropertyDescriptor) {
        console.log(target);
        console.log(key);
        console.log(descriptor);
        const originalFunc = descriptor.value;

        descriptor.value = function () {
            console.log(gstPercentage)
            const gstAmount = arguments[2] * gstPercentage / 100;
            return originalFunc(arguments[0], arguments[1], arguments[2]) - gstAmount;
        };
        return descriptor;
    }
}
class IndianSalesCalculator {

    //@gst(18)
    salesNetProfit(cogs: number, expense: number, actualSales: number): number {
        return actualSales - (cogs + expense);
    }
}

const sales = new IndianSalesCalculator();
console.log(sales.salesNetProfit(12000, 13000, 150000));

